import nltk
from nltk.corpus import stopwords
import re

nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

def simplify_text(text):
    replacements = {
        r'sql injection': 'database manipulation attack',
        r'cross-site scripting': 'website code injection',
        r'\bcwe-\d+\b': 'vulnerability type',
        r'\bunion\b': 'data combination',
        r'\btautology\b': 'always-true condition'
    }
    
    text = text.lower()
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text)
    
    return text.capitalize()