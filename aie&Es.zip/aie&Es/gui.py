import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
from text_utils import simplify_text

class ScannerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Vulnerability Scanner")
        self.root.geometry("800x600")
        
        # UI Elements
        self.url_entry = ttk.Entry(width=50)
        self.scan_btn = ttk.Button(text="Start Scan", command=self.start_scan)
        self.results_tree = ttk.Treeview(columns=("Vulnerability", "Severity", "Action"))
        self.status = ttk.Label(text="Ready")
        
        # Layout
        ttk.Label(text="Target URL:").pack(pady=5)
        self.url_entry.pack(pady=5)
        self.scan_btn.pack(pady=5)
        self.results_tree.pack(expand=True, fill='both')
        self.status.pack(side='bottom')
        
    def start_scan(self):
        url = self.url_entry.get()
        if not url.startswith("http"):
            messagebox.showerror("Error", "Invalid URL format")
            return
            
        self.status.config(text="Scanning...")
        threading.Thread(target=self.run_scan, args=(url,)).start()
    
    def run_scan(self, url):
        from zap_scanner import ZAPScanner
        from ai_module import AIModel
        
        scanner = ZAPScanner()
        ai = AIModel()
        ai.train("vulnerabilities.csv")
        
        results = scanner.scan(url)
        for vuln in results:
            cwe, severity = ai.predict(vuln['name'], vuln['description'])
            simple_desc = simplify_text(vuln['description'])
            
            self.results_tree.insert("", "end", values=(
                simple_desc,
                f"Severity: {severity:.1f}/10",
                "Immediate patching recommended" if severity > 7 else "Schedule update"
            ))
        
        self.status.config(text="Scan completed")