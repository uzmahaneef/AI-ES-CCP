import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder
import tensorflow as tf

class AIModel:
    def __init__(self):
        self.svm = SVC()
        self.ann = self._build_ann()
        self.label_encoder = LabelEncoder()
        
    # ai_module.py
    def _build_ann(self):
        model = tf.keras.Sequential([
            tf.keras.layers.Input(shape=(2,)),  # Add explicit Input layer
            tf.keras.layers.Dense(8, activation='relu'),
            tf.keras.layers.Dense(1, activation='linear')
        ])
        model.compile(optimizer='adam', loss='mse')
        return model
    
    def train(self, data_path):
        df = pd.read_csv(data_path)
        
        # SVM Training (CWE Classification)
        texts = df['ZAP Alert Name'] + " " + df['Description']
        self.word_index = {word: idx for idx, word in enumerate(set(" ".join(texts).split()))}
        X_svm = np.array([[self.word_index.get(word,0) for word in text.split()] for text in texts])
        X_svm = X_svm.mean(axis=1).reshape(-1,1)
        
        self.label_encoder.fit(df['CWE'])
        y_svm = self.label_encoder.transform(df['CWE'])
        self.svm.fit(X_svm, y_svm)
        
        # ANN Training (Severity Prediction)
        X_ann = df[['CWE', 'Risk']].replace({'CWE': self.label_encoder.classes_}).values
        y_ann = df['Risk'].values
        self.ann.fit(X_ann, y_ann, epochs=10, verbose=0)
    
    def predict(self, alert_name, description):
        # SVM Prediction
        text = alert_name + " " + description
        words = [self.word_index.get(word,0) for word in text.split()]
        cwe_idx = self.svm.predict([np.mean(words)])[0]
        cwe = self.label_encoder.inverse_transform([cwe_idx])[0]
        
        # ANN Prediction
        severity = self.ann.predict([[cwe_idx, 5]])[0][0]  # Default risk=5
        return cwe, severity